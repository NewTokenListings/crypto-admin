Deploy Fix Bundle (GitHub Pages + Custom Domain)

Files:
- vite.config.js -> base: "/" for custom domain builds
- public/404.html -> SPA-friendly fallback
- public/CNAME -> binds Pages to admin.newtokenlistings.com
- package.json.example -> merge homepage + deploy script

Apply:
1) Copy these into your repo (merge public/). Overwrite vite.config.js.
2) Ensure package.json includes homepage + deploy script.
3) git add vite.config.js public/404.html public/CNAME package.json
   git commit -m "fix(deploy): custom domain build, SPA 404, CNAME for GitHub Pages"
   git push origin main
4) rm -rf dist && npm run build && npm run deploy
